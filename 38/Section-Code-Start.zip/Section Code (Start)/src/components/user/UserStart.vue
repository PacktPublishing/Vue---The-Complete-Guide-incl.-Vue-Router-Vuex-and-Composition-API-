<template>
    <div>
        <p>Please select a User</p>
        <hr>
        <ul class="list-group">
            <li class="list-group-item" style="cursor: pointer">User 1</li>
            <li class="list-group-item" style="cursor: pointer">User 2</li>
            <li class="list-group-item" style="cursor: pointer">User 3</li>
        </ul>
    </div>
</template>