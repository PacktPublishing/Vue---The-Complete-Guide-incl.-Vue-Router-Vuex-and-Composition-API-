import { createApp } from 'vue';

createApp({}).mount('#app');
