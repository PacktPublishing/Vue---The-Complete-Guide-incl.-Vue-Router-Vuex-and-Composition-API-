<template>
  <div>
    <h2>This is Foo!</h2>
    <p>I am lazy-loaded. (check out the Networks tab in Chrome devtools)</p>
  </div>
</template>
