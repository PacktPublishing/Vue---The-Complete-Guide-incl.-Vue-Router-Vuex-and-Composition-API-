<template>
  <h2>{{ counter }}</h2>
</template>

<script>
export default {
  setup() {
    const counter = 0;

    return { counter };
  },
};
</script>