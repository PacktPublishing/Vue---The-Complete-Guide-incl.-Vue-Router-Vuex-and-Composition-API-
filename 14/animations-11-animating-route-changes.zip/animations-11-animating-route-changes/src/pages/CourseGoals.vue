<template>
  <div class="container">
    <h2>Course Goals</h2>
    <router-link to="/">All Users</router-link>
  </div>
</template>