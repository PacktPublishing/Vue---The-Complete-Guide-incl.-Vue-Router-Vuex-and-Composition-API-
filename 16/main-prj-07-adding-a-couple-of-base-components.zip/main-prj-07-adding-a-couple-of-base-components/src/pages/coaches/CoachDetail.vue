<template>
  DETAILS FOR COACH
  <router-view></router-view>
  <router-link to="/coaches/c1/contact">Contact</router-link>
</template>