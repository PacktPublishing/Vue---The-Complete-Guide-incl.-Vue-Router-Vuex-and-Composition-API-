<template>
  <section>
    FILTER
  </section>
  <section>
    LIST OF COACHES
  </section>
</template>