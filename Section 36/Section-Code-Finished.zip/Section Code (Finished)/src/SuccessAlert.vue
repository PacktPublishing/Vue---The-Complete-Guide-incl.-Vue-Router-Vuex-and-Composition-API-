<template>
    <div class="alert alert-success">This is successful!</div>
</template>