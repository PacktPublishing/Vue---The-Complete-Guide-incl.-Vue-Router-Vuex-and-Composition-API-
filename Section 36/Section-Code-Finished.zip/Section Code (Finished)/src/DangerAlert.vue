<template>
    <div class="alert alert-danger">This is dangerous!</div>
</template>